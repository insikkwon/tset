const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.set('views', './views');
app.set('view engine', 'jade');

app.get('/upload', (req, res) => {
    res.render('upload');
});

app.get('/download', (req, res) => {
    res.download('./upload/samplefile');
});

app.post('/upload', (req, res) => {
    const upload = multer({ storage: storage }).single('myfile');
    upload(req, res, (err) => {
        if (req.fileValidationError) {
            return res.send(req.fileValidationError);
        }
        else if (!req.file) {
            return res.send('Please select an image to upload');
        }
        else if (err instanceof multer.MulterError) {
            return res.send(err);
        }
        else if (err) {
            return res.send(err);
        }
        res.send(`Uploaded: ${req.file.filename}`);
    });
})

app.listen(3000, () => {
    console.log('Connected 3000');
})
